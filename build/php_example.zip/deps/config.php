<?php /* vim: set expandtab tabstop=2 shiftwidth=2 softtabstop=2 */
/* config.php */

$config = [
  'url' => 'http://127.0.0.1:4445',
  'auth' => false,
  'key' => '7z68p0ts3iohxc5v',
];

