<!-- vim: set expandtab tabstop=2 shiftwidth=2 softtabstop=2 -->
<!DOCTYPE html>
<html>
  <head>
    <title></title>
    <link rel="stylesheet" href="static/bootstrap.css">
    <script src="static/jquery.js"></script>
  </head>
  <body>


    <div class="container">

      <div class="col-sm-12"><h1>Best Diet Product</h1></div>

      <div class="col-sm-7">
        <img src="static/weight-loss.jpg" style="width:100%;border-radius:30px">
      </div>

      <div class="col-md-5">

      <div class=" well">
        <h3 class="form-signin-heading">Thank You!</h2>
        <p>Thank you for your order, your subscription has been created.</p>
        <p><a href="index.php">(restart and clear session)</a></p>
      </div>

    </div>
    </div>

    <script src="static/main.js"></script>

  </body>
</html>

